from Tkinter import *
from PIL import *
import Tkinter, Tkconstants, tkFileDialog
import ImageWriter
import Image, ImageFilter, ImageDraw


class Window:
    def __init__(self,parent=None):
        self.frame = Frame(parent,bg="white")
        self.frame.pack(expand=True,fill=BOTH)
        self.allbuttons = []
        menubar = Menu(parent)
        menubar.add_command(label="File")
        menubar.add_command(label="Quit",command=parent.quit)
        
        ##Buttons
        #rotation button refer to the rotation function once it is clicked
        rotation = Label(self.frame, text="Degrees of rotation: ") 
        rotation.grid(column=0, row=0)
        box = Entry(self.frame)
        box.grid(column=1, row=0)
        self.rotatebtn= Button(self.frame,text="Rotate", command=lambda: self.Rotate(box))
        self.rotatebtn.grid(column=2, row=0)
        self.allbuttons.append(self.rotatebtn)

        
        #text buttton refer to the text button once it is clicked
        self.textbtn= Button(self.frame, text="Text", command=self.Text)
        self.allbuttons.append(self.textbtn)
        self.textbtn.grid(column=0,row=1)

        #blur button refer to the blur function once it is clicked
        self.blurbtn= Button(self.frame, text="Blur", command= self.Blur)
        self.allbuttons.append(self.blurbtn)
        self.blurbtn.grid(column=0,row=2)
        
        parent.config(menu=menubar)
        
        #menu bar
        #drop down list for open and save functions
        filemenu = Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open", command=self.Open)
        filemenu.add_command(label="Save", command = self.Save)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=parent.quit)
        menubar.add_cascade(label="File", menu=filemenu)
        #menu bar
        #drop down list for undo and redo functions
        fileMenu = Menu(menubar, tearoff=0)        
        fileMenu.add_command(label="Undo")
        fileMenu.add_command(label="Redo")
        menubar.add_cascade(label="Edit", menu=fileMenu)

    
    
    def Open(self):
        self.filename = tkFileDialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*")))
        global FileName
        global pic
        FileName=str(self.filename)
        pic = Image.open(FileName)

        
    def Save(self):
        self.filename = tkFileDialog.asksaveasfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*")))
        name= str(self.filename)[72:]
        pic.save("hi.jpg")
        
    #this function blur the whole image
    #then it saves it in the same location as this file 
    def Blur(self):
        blurimage = pic.filter(ImageFilter.BLUR)
        blurimage.save("hello.jpg")

    #this function writes a text in the code once clicking on the text button
    #then it saves it in the same location as this file
    def Text(self):
        draw = ImageDraw.Draw(pic)
        draw.text(xy=(50,50),text="Hello", fill=(255,69,0))
        pic.save("text.jpg")
    #this function rotates the image with the amount of degree that the user specify
    #then it saves it in the same location as this file
    def Rotate(self,box):        
        rotateimage=pic.rotate(float(box.get()))
        rotateimage.save("rotateimage.jpg")
        
        


        

wnd = Tk()
wnd.geometry("1500x1500")
myWindow = Window(wnd)
wnd.mainloop()
print "Done"
