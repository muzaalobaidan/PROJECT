from Tkinter import *
from PIL import *
import Tkinter, Tkconstants, tkFileDialog
import ImageWriter
import Image, ImageFilter, ImageDraw
import ImageTk
import ImageEnhance

## Code designed and written by: Muza Alobaidan
## Andrew ID: mjalobai
## File Created: November 4, 2:00pm
## Modification History:
## Start          End
## 04/11 2:00pm   04/11 3:30pm
## 05/11 9:30am   05/11 12:15pm
## 06/11 8:00pm   06/11 10:15pm
## 10/11 3:00pm   10/11 05:25pm
## 11/11 12:00pm  11/11 02:30pm
## 11/11 4:00pm   11/11 08:00pm
## 12/11 9:00am   12/11 12:25pm
## 14/11 5:00pm   14/11 8:30pm
## 18/11 1:00pm   18/11 5:00pm
## 19/11 6:00pm   19/11 9:15pm
## 21/11 10:00am  21/11 12:30pm
## 21/11 4:00pm   21/11 6:30pm
## 22/11 8:30am   22/11 10:00am
## 22/11 5:00pm   22/11 7:00pm
## 23/11 9:30am   23/11 12:45pm
## 23/11 4:45pm   23/11 7:00pm
## 25/11 9:00am   25/11 1:30pm
## 25/11 4:00pm   25/11 1:00am
 
class Window:
    def __init__(self,parent=None):
        self.frame = Frame(parent,bg="white")
        self.frame.pack(expand=True,fill=BOTH)
        self.allbuttons = []
        menubar = Menu(parent) #creates menu bar 
        
        ##Buttons
        #rotation button refer to the rotation function once it is clicked
        rotation = Label(self.frame,bg="white", text="Degrees of rotation: ") 
        rotation.grid(column=0, row=0, padx=5,pady=12)
        box = Entry(self.frame)
        box.grid(column=1, row=0)
        self.rotatebtn= Button(self.frame,text="Rotate", command=lambda: self.Rotate(box))
        self.rotatebtn.grid(column=2, row=0)
        self.allbuttons.append(self.rotatebtn)
        
        #text buttton refer to the text button once it is clicked
        textbox = Label(self.frame, bg="white",text="Text") 
        textbox.grid(column=0, row=1,padx=5,pady=12)
        Box = Entry(self.frame)
        Box.grid(column=0, row=2)
        Boxx = Entry(self.frame)
        Boxx.grid(column=1, row=2)
        textboxx = Label(self.frame,bg="white", text="X position") 
        textboxx.grid(column=1, row=1)
        Boxy = Entry(self.frame)
        Boxy.grid(column=2, row=2)
        textboxy = Label(self.frame, bg="white",text="Y position") 
        textboxy.grid(column=2, row=1)

        #saveas entry to save images in the folder that the file of code is in 
        saveas = Label(self.frame, bg="white",text="Save as") 
        saveas.grid(column=3, row=1)
        Boxsaveas = Entry(self.frame)
        Boxsaveas.grid(column=3, row=2)
        
        self.textbtn= Button(self.frame, text="Enter", command=lambda: self.Text(Box,Boxx,Boxy,Boxsaveas)) 
        self.allbuttons.append(self.textbtn)
        self.textbtn.grid(column=4,row=2)

        #blur button refer to the blur function once it is clicked
        textboxblur = Label(self.frame, bg="white",text="Press button to blur photo") 
        textboxblur.grid(column=0, row=3,padx=5,pady=25)
        self.blurbtn= Button(self.frame, text="Blur", command= self.Blur)
        self.allbuttons.append(self.blurbtn)
        self.blurbtn.grid(column=1,row=3)
        
        #grayscale button refer to the grayscale function once it is clicked
        grayscalelabel = Label(self.frame, bg="white",text="Press button to convert photo to Grayscale")
        grayscalelabel.grid(column=0, row=4,padx=5,pady=25)
        self.grayscalebtn= Button(self.frame, text="Grayscale", command= self.Grayscale)
        self.allbuttons.append(self.grayscalebtn)
        self.grayscalebtn.grid(column=1,row=4)
        #red button refer to the red function once it is clicked
        redlabel = Label(self.frame, bg="white",text="Press button to convert photo to Red")
        redlabel.grid(column=0, row=5,padx=5,pady=25)
        self.redbtn= Button(self.frame, text="Red", command= self.convertRed)
        self.allbuttons.append(self.redbtn)
        self.redbtn.grid(column=1,row=5)
        #green button refer to the green function once it is clicked
        greenlabel = Label(self.frame, bg="white",text="Press button to convert photo to Green")
        greenlabel.grid(column=0, row=6,padx=5,pady=25)
        self.greenbtn= Button(self.frame, text="Green", command= self.convertGreen)
        self.allbuttons.append(self.greenbtn)
        self.greenbtn.grid(column=1,row=6)
        #blue button refer to the blue function once it is clicked
        bluelabel = Label(self.frame, bg="white",text="Press button to convert photo to Blue")
        bluelabel.grid(column=0, row=7,padx=5,pady=25)
        self.bluebtn= Button(self.frame, text="Blue", command= self.convertBlue)
        self.allbuttons.append(self.bluebtn)
        self.bluebtn.grid(column=1,row=7)
        #crop button refer to the crop function once it is clicked
        croplabel = Label(self.frame,bg="white", text="crop coordinates: ") 
        croplabel.grid(column=0, row=8, padx=5,pady=12)
        boxcrop1 = Entry(self.frame)
        boxcrop1.grid(column=1, row=8)
        boxcrop2 = Entry(self.frame)
        boxcrop2.grid(column=2, row=8)
        boxcrop3 = Entry(self.frame)
        boxcrop3.grid(column=3, row=8)
        boxcrop4 = Entry(self.frame)
        boxcrop4.grid(column=4, row=8)
        self.cropbtn= Button(self.frame,text="Crop", command=lambda: self.Crop(boxcrop1,boxcrop2,boxcrop3,boxcrop4))
        self.cropbtn.grid(column=5, row=8)
        self.allbuttons.append(self.cropbtn)
        #saturation button refer to the saturation function once it is clicked
        satlabel = Label(self.frame,bg="white", text="number from 0.0 to 10.0: ") 
        satlabel.grid(column=0, row=9, padx=5,pady=12)
        boxofsat = Entry(self.frame)
        boxofsat.grid(column=1, row=9)
        self.satbtn= Button(self.frame,text="Saturation", command=lambda: self.Saturation(boxofsat))
        self.satbtn.grid(column=2, row=9)
        self.allbuttons.append(self.satbtn)
        #brightness button refer to the brightness function once it is clicked
        brightlabel = Label(self.frame,bg="white", text="number from 0.0 to 10.0: ") 
        brightlabel.grid(column=0, row=10, padx=5,pady=12)
        boxofbright = Entry(self.frame)
        boxofbright.grid(column=1, row=10)
        self.brightbtn= Button(self.frame,text="Brightness", command=lambda: self.Brightness(boxofbright))
        self.brightbtn.grid(column=2, row=10)
        self.allbuttons.append(self.brightbtn)
        #sharpness button refer to the sharpness function once it is clicked
        sharplabel = Label(self.frame,bg="white", text="number from 0.0 to 10.0: ") 
        sharplabel.grid(column=0, row=11, padx=5,pady=12)
        boxofsharp = Entry(self.frame)
        boxofsharp.grid(column=1, row=11)
        self.sharpbtn= Button(self.frame,text="Sharpness", command=lambda: self.Sharpness(boxofsharp))
        self.sharpbtn.grid(column=2, row=11)
        self.allbuttons.append(self.sharpbtn)
        #contrast button refer to the contrast function once it is clicked
        contrastlabel = Label(self.frame,bg="white", text="number from 0.0 to 10.0: ") 
        contrastlabel.grid(column=0, row=12, padx=5,pady=12)
        boxofontrast = Entry(self.frame)
        boxofontrast.grid(column=1, row=12)
        self.contrastbtn= Button(self.frame,text="Contrast", command=lambda: self.Contrast(boxofontrast))
        self.contrastbtn.grid(column=2, row=12)
        self.allbuttons.append(self.contrastbtn)
        #resize button refer to the resize function once it is clicked
        resizelabel = Label(self.frame,bg="white", text="Enter a number: ") 
        resizelabel.grid(column=0, row=13, padx=5,pady=12)
        boxofresize1 = Entry(self.frame)
        boxofresize1.grid(column=1, row=13)
        boxofresize2 = Entry(self.frame)
        boxofresize2.grid(column=2, row=13)
        self.resizebtn= Button(self.frame,text="Resize", command=lambda: self.Resize(boxofresize1,boxofresize2))
        self.resizebtn.grid(column=3, row=13)
        self.allbuttons.append(self.resizebtn)
        
        parent.config(menu=menubar)
        
        #menu bar
        #drop down list for open and save functions
        filemenu = Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open",command=self.Open)
        filemenu.add_command(label="Save", command = self.Save)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=parent.quit)
        menubar.add_cascade(label="File", menu=filemenu)

    
    #this function open the open dialog box to open an image
    def Open(self):
        #https://pythonspot.com/en/tk-file-dialogs/ 
        self.filename = tkFileDialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("png files","*.png"),("all files","*.*")))
        global FileName #global used to be able to call whatever after it in all other functions
        global pic
        global openn
        global closewin
        global closetext
        global closerotate
        global closegray
        global closecrop
        global closesat
        global closebright
        global closesharp
        global closeresize
        global closeblue
        global closered
        global closegreen
        
        #initializing variables
        closewin=0
        closetext=0
        closerotate=0
        closegray=0
        closecrop=0
        closesat=0
        closebright=0
        closesharp=0
        closeresize=0
        closeblue=0
        closered=0
        closegreen=0

        pic = Image.open(str(self.filename)) #open an image

        global openn
        openn = ImageWriter.loadPicture(str(self.filename)) #load image then show it
        ImageWriter.showPicture(openn)
        
    #open the save dialog box
    #save the picture as hi.jpg in the same location of the file
    def Save(self):
        #https://pythonspot.com/en/tk-file-dialogs/
        self.filename = tkFileDialog.asksaveasfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("png files","*.png"),("all files","*.*")))
        name= str(self.filename)[72:]
        pic.save("hi.jpg")
        
    #this function blur the whole image (change the filter of the image)
    #then it saves it in the same location as this file
    #by default it saves it as hello.jpg in the same folder of the file
    def Blur(self):
        global blur
        global closetext
        global closerotate
        global closegray

        blurimage = pic.filter(ImageFilter.GaussianBlur(100)) #blur the image
        blurimage.save("blur.jpg")


        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        global closewin
        closewin=1
        blur = ImageWriter.loadPicture("blur.jpg") #close the image opened and open the blurred image at the same time and show it
        ImageWriter.showPicture(blur)

    #this function writes a text in the code once clicking on the text button
    #then it saves it in the same location as this file
    #the text Hello will be typed in orange in (50,50)
    #by default it will be saved as text.jpg in the same folder of this file
    def Text(self,Box,Boxx,Boxy,Boxsaveas):
        global text
        global closewin
        global closetext
        global closerotate
        global closegray
        #write a text and choose coordinates for it as well as saving it without extension
        #close the image once clicked on enter button and open the image saved with the text
        #show the picture
        draw = ImageDraw.Draw(pic)
        draw.text(xy=(int(Boxx.get()),int(Boxy.get())),text=Box.get(), fill=(0,0,0))  
        pic.save(Boxsaveas.get()+".jpg")


        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
        ImageWriter.close(openn)
        closetext=1
        
        text = ImageWriter.loadPicture(Boxsaveas.get()+".jpg") 
        ImageWriter.showPicture(text)
    #this function rotates the image with the amount of degree that the user specify in the entry
    #then it saves it in the same location as this file by the name of rotateimage.jpg
    def Rotate(self,box):
        global rotate
        global closewin
        global closetext
        global closerotate
        global closegray
        #rotate the image to different angles then open the image saved and close the previous one
        #show picture
        rotateimage=pic.rotate(float(box.get()))
        rotateimage.save("rotateimage.jpg")
        ImageWriter.close(openn)

        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closerotate=1
        rotate = ImageWriter.loadPicture("rotateimage.jpg")
        ImageWriter.showPicture(rotate)
        
    def Grayscale(self):
        global gray
        global closewin
        global closetext
        global closerotate
        global closegray
        #convert the image to grayscale then open the image saved and close the previous one
        #show picture
        gray=pic.convert("L")
        gray.save("grayscale.jpg")
        
        ImageWriter.close(openn) #this function closes the first picture opened 

        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closegray=1
        gray = ImageWriter.loadPicture("grayscale.jpg")
        ImageWriter.showPicture(gray)
        

        
    def convertRed(self):
        global gray
        global closewin
        global closetext
        global closerotate
        global closegray
        global closered
        global openn
        #find the size of the image
        #get the color of the image when it is less than 127.5 convert it to dark red if not then to light red
        #set the color identified
        #save the picture
        #close the opened image and open the edited one
        #show picture
        W=ImageWriter.getWidth(openn)
        H=ImageWriter.getHeight(openn)
        for i in range(W):
            for j in range(H):
                A=ImageWriter.getColor(openn,i,j)
                Color=(A[0]+A[1]+A[2])/3
                if Color<127.5:
                    C=[255,153,153]
                else:
                    C=[255,51,51]
                ImageWriter.setColor(openn,i,j,C)
        ImageWriter.savePicture(openn, "red.jpg")
        
        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closered=1
        red = ImageWriter.loadPicture("red.jpg")
        ImageWriter.showPicture(red)


    def convertGreen(self):
        global gray
        global closewin
        global closetext
        global closerotate
        global closegray
        global openn
        #find the size of the image
        #get the color of the image when it is less than 127.5 convert it to dark green if not then to light green
        #set the color identified
        #save the picture
        #close the opened image and open the edited one
        #show picture
        W=ImageWriter.getWidth(openn)
        H=ImageWriter.getHeight(openn)
        for i in range(W):
            for j in range(H):
                A=ImageWriter.getColor(openn,i,j)
                Color=(A[0]+A[1]+A[2])/3
                if Color<127.5:
                    C=[0,204,0]
                else:
                    C=[204,255,204]
                ImageWriter.setColor(openn,i,j,C)
        ImageWriter.updatePicture(openn)
        ImageWriter.savePicture(openn, "green.jpg")
        
        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closegreen=1
        green = ImageWriter.loadPicture("green.jpg")
        ImageWriter.showPicture(green)

    def convertBlue(self):
        global gray
        global closewin
        global closetext
        global closerotate
        global closegray
        global closeblue
        global openn
        #find the size of the image
        #get the color of the image when it is less than 127.5 convert it to dark blue if not then to light blue
        #set the color identified
        #save the picture
        #close the opened image and open the edited one
        #show picture
        W=ImageWriter.getWidth(openn)
        H=ImageWriter.getHeight(openn)
        for i in range(W):
            for j in range(H):
                A=ImageWriter.getColor(openn,i,j)
                Color=(A[0]+A[1]+A[2])/3
                if Color<127.5:
                    C=[153,204,255]
                else:
                    C=[204,229,255]
                ImageWriter.setColor(openn,i,j,C)
        ImageWriter.savePicture(openn, "blue.jpg")
        
        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closeblue=1
        blue = ImageWriter.loadPicture("blue.jpg")
        ImageWriter.showPicture(blue)

    def Crop(self,boxcrop1,boxcrop2,boxcrop3,boxcrop4):
        global crop
        global closewin
        global closetext
        global closerotate
        global closegray
        global closecrop
        #get the values in the entry boxes
        #crop the image
        #close the opened image which is the real one then open the cropped image
        #show picture
        cropimage = pic.crop((int(boxcrop1.get()),int(boxcrop2.get()),int(boxcrop3.get()),int(boxcrop4.get())))
        cropimage.save("cropimage.jpg")
        
        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closewin=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
            
        closecrop=1
        crop = ImageWriter.loadPicture("cropimage.jpg")
        ImageWriter.showPicture(crop)

    def Saturation(self,boxofsat):
        global sat 
        global closewin
        global closetext
        global closerotate
        global closegray
        global closesat
        #get the value in the entry box
        #convert the image to saturation
        #close the opened image and open the edited one
        #show picture
        enhancer = ImageEnhance.Color(pic)
        enhancer.enhance(float(boxofsat.get())).save("saturation.jpg")

        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closetext=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
    
        closesat=1
        sat = ImageWriter.loadPicture("saturation.jpg")
        ImageWriter.showPicture(sat)
    def Brightness(self,boxofbright):
        global bright
        global closewin
        global closetext
        global closerotate
        global closegray
        global closebright
        #get the value in the entry box
        #convert the image to brightness
        #close the opened image and open the edited one
        #show picture
        enhancer = ImageEnhance.Brightness(pic)
        enhancer.enhance(float(boxofbright.get())).save("bright.jpg")

        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closetext=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0

        closebright=1
        bright = ImageWriter.loadPicture("bright.jpg")
        ImageWriter.showPicture(bright)
    def Sharpness(self,boxofsharp):
        global sharp
        global closewin
        global closetext
        global closerotate
        global closegray
        global closesharp
        #get the value in the entry box
        #convert the image to sharpness
        #close the opened image and open the edited one
        #show picture
        enhancer = ImageEnhance.Sharpness(pic)
        enhancer.enhance(float(boxofsharp.get())).save("sharp.jpg")

        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closetext=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
            
        closesharp=1
        sharp = ImageWriter.loadPicture("sharp.jpg")
        ImageWriter.showPicture(sharp)
    def Resize(self, boxofresize1,boxofresize2):
        global resize
        global closewin
        global closetext
        global closerotate
        global closegray
        global closeresize
        #get the value in the entry boxes
        #resize the image to identified values
        #close the opened image and open the edited one
        #show picture
        resize = pic.resize((int(boxofresize1.get()),int(boxofresize2.get())))
        resize.save("resize.jpg")

        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closetext=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
            
        closeresize=1    
        resize = ImageWriter.loadPicture("resize.jpg")
        ImageWriter.showPicture(resize)

    def Contrast(self,boxofontrast):
        global contrast
        global closewin
        global closetext
        global closerotate
        global closegray
        global closecontrast
        #get the value in the entry box
        #convert the image to contrast
        #close the opened image and open the edited one
        #show picture
        enhancer = ImageEnhance.Contrast(pic)
        enhancer.enhance(float(boxofontrast.get())).save("contrast.jpg")
        ImageWriter.close(openn)
        if closewin==1:
            ImageWriter.close(blur)
            closetext=0
        if closetext==1:
            ImageWriter.close(text)
            closetext=0
        if closerotate==1:
            ImageWriter.close(rotate)
            closerotate=0
        if closegray==1:
            ImageWriter.close(gray)
            closegray=0
        closecontrast=1
        cont = ImageWriter.loadPicture("contrast.jpg")
        ImageWriter.showPicture(cont)

    
    
wnd = Tk()
wnd.geometry("2400x2400")
myWindow = Window(wnd)
wnd.mainloop()

